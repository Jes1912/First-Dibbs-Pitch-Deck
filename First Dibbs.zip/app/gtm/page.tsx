"use client"

import GTMStrategyPage from "@/components/gtm-strategy-page"

export default function GTMPage() {
  return <GTMStrategyPage />
}
